<!--BREADCRUMBS BEGIN-->
<section class="image-header">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="info">
                    <div class="wrap">
                        <ul class="breadcrumbs">
                            <li><a href="<?php echo BASE_URL; ?>">Beranda</a>/</li>
                            <li>Klasemen Liga</li>
                        </ul>
                        <h1>Klasemen Liga</h1>
                    </div>
                </div>
            </div>	
        </div>
    </div>
</section>
<!--BREADCRUMBS END-->

<!--STANDING TABLE WRAP BEGIN-->

<section class="standing-table-wrap">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <h4>Premier league</h4>
                <ul class="tab-filters" role="tablist">
                    <li class="active"><a href="#2017" role="tab" data-toggle="tab">2017</a></li>
                    <li><a href="#2016" role="tab" data-toggle="tab">2016</a></li>
                    <li><a href="#2015" role="tab" data-toggle="tab">2015</a></li>
                    <li><a href="#2014" role="tab" data-toggle="tab">2014</a></li>
                </ul>
            </div>

            <div class="col-md-12 col-sm-12 col-xs-12 overflow-scroll standings-table"> 
                <div class="tab-content">
                    <div class="tab-pane fade in active" id="2017" role="tabpanel">
                        <table class="standing-full">
                            <tr>
                                <th>club</th>
                                <th>played</th>
                                <th>won</th>
                                <th>drawn</th>
                                <th>lost</th>
                                <th>gd</th>
                                <th>points</th>
                                <th>form</th>
                                <th>next</th>
                            </tr>
                            <tr>
                                <td class="up">
                                    <i class="fa fa-caret-up" aria-hidden="true"></i> 1 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo1.png" width="30" height="30" alt="team-logo"> </span>Team 1
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>2</td>
                                <td>1</td>
                                <td>+16</td>
                                <td class="points"><span>26</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo2.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="down">
                                    <i class="fa fa-caret-down" aria-hidden="true"></i> 2 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo2.png" width="30" height="30" alt="team-logo"> </span>Team 2
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>1</td>
                                <td>2</td>
                                <td>+14</td>
                                <td class="points"><span>23</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="lose">l</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo1.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="down">
                                    <i class="fa fa-caret-down" aria-hidden="true"></i> 2 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo3.png" width="30" height="30" alt="team-logo"> </span>Team 3
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>1</td>
                                <td>2</td>
                                <td>+13</td>
                                <td class="points"><span>23</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="lose">l</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo4.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="down">
                                    <i class="fa fa-caret-down" aria-hidden="true"></i> 2 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo4.png" width="30" height="30" alt="team-logo"> </span>Team 4
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>1</td>
                                <td>2</td>
                                <td>+10</td>
                                <td class="points"><span>23</span></td>
                                <td class="form">
                                    <span class="lose">l</span>
                                    <span class="drawn">d</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo3.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="none">
                                    <i class="fa fa-circle" aria-hidden="true"></i> 3 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo5.png" width="30" height="30" alt="team-logo"> </span>Team 5
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>2</td>
                                <td>2</td>
                                <td>+16</td>
                                <td class="points"><span>20</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo1.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="2016" role="tabpanel">
                        <table class="standing-full">
                            <tr>
                                <th>club</th>
                                <th>played</th>
                                <th>won</th>
                                <th>drawn</th>
                                <th>lost</th>
                                <th>gd</th>
                                <th>points</th>
                                <th>form</th>
                                <th>next</th>
                            </tr>
                            <tr>
                                <td class="up">
                                    <i class="fa fa-caret-up" aria-hidden="true"></i> 1 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo1.png" width="30" height="30" alt="team-logo"> </span>Team 5
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>2</td>
                                <td>1</td>
                                <td>+16</td>
                                <td class="points"><span>26</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo2.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="down">
                                    <i class="fa fa-caret-down" aria-hidden="true"></i> 1 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo2.png" width="30" height="30" alt="team-logo"> </span>Team 1
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>2</td>
                                <td>1</td>
                                <td>+16</td>
                                <td class="points"><span>26</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo1.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="down">
                                    <i class="fa fa-caret-down" aria-hidden="true"></i> 1 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo3.png" width="30" height="30" alt="team-logo"> </span>Team 2
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>2</td>
                                <td>1</td>
                                <td>+16</td>
                                <td class="points"><span>26</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo4.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="down">
                                    <i class="fa fa-caret-down" aria-hidden="true"></i> 1 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo4.png" width="30" height="30" alt="team-logo"> </span>Team 3
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>2</td>
                                <td>1</td>
                                <td>+16</td>
                                <td class="points"><span>26</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo3.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="none">
                                    <i class="fa fa-circle" aria-hidden="true"></i> 1 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo5.png" width="30" height="30" alt="team-logo"> </span>Team 4
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>2</td>
                                <td>1</td>
                                <td>+16</td>
                                <td class="points"><span>26</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo1.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="2015" role="tabpanel">
                        <table class="standing-full">
                            <tr>
                                <th>club</th>
                                <th>played</th>
                                <th>won</th>
                                <th>drawn</th>
                                <th>lost</th>
                                <th>gd</th>
                                <th>points</th>
                                <th>form</th>
                                <th>next</th>
                            </tr>
                            <tr>
                                <td class="up">
                                    <i class="fa fa-caret-up" aria-hidden="true"></i> 1 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo1.png" width="30" height="30" alt="team-logo"> </span>Team 1
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>2</td>
                                <td>1</td>
                                <td>+16</td>
                                <td class="points"><span>26</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo2.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="down">
                                    <i class="fa fa-caret-down" aria-hidden="true"></i> 2 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo2.png" width="30" height="30" alt="team-logo"> </span>Team 2
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>1</td>
                                <td>2</td>
                                <td>+14</td>
                                <td class="points"><span>23</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="lose">l</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo1.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="down">
                                    <i class="fa fa-caret-down" aria-hidden="true"></i> 2 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo3.png" width="30" height="30" alt="team-logo"> </span>Team 3
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>1</td>
                                <td>2</td>
                                <td>+13</td>
                                <td class="points"><span>23</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="lose">l</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo4.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="down">
                                    <i class="fa fa-caret-down" aria-hidden="true"></i> 2 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo4.png" width="30" height="30" alt="team-logo"> </span>Team 4
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>1</td>
                                <td>2</td>
                                <td>+10</td>
                                <td class="points"><span>23</span></td>
                                <td class="form">
                                    <span class="lose">l</span>
                                    <span class="drawn">d</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo3.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="none">
                                    <i class="fa fa-circle" aria-hidden="true"></i> 3 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo5.png" width="30" height="30" alt="team-logo"> </span>Team 5
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>2</td>
                                <td>2</td>
                                <td>+16</td>
                                <td class="points"><span>20</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo1.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="2014" role="tabpanel">
                        <table class="standing-full">
                            <tr>
                                <th>club</th>
                                <th>played</th>
                                <th>won</th>
                                <th>drawn</th>
                                <th>lost</th>
                                <th>gd</th>
                                <th>points</th>
                                <th>form</th>
                                <th>next</th>
                            </tr>
                            <tr>
                                <td class="up">
                                    <i class="fa fa-caret-up" aria-hidden="true"></i> 1 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo1.png" width="30" height="30" alt="team-logo"> </span>Team 5
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>2</td>
                                <td>1</td>
                                <td>+16</td>
                                <td class="points"><span>26</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo2.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="down">
                                    <i class="fa fa-caret-down" aria-hidden="true"></i> 1 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo2.png" width="30" height="30" alt="team-logo"> </span>Team 1
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>2</td>
                                <td>1</td>
                                <td>+16</td>
                                <td class="points"><span>26</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo1.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="down">
                                    <i class="fa fa-caret-down" aria-hidden="true"></i> 1 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo3.png" width="30" height="30" alt="team-logo"> </span>Team 2
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>2</td>
                                <td>1</td>
                                <td>+16</td>
                                <td class="points"><span>26</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo4.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="down">
                                    <i class="fa fa-caret-down" aria-hidden="true"></i> 1 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo4.png" width="30" height="30" alt="team-logo"> </span>Team 3
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>2</td>
                                <td>1</td>
                                <td>+16</td>
                                <td class="points"><span>26</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo3.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                            <tr>
                                <td class="none">
                                    <i class="fa fa-circle" aria-hidden="true"></i> 1 <span class="team"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo5.png" width="30" height="30" alt="team-logo"> </span>Team 4
                                </td>
                                <td>11</td>
                                <td>8</td>
                                <td>2</td>
                                <td>1</td>
                                <td>+16</td>
                                <td class="points"><span>26</span></td>
                                <td class="form">
                                    <span class="win">w</span>
                                    <span class="drawn">d</span>
                                    <span class="lose">l</span>
                                    <span class="win">w</span>
                                    <span class="win">w</span>
                                </td>
                                <td><a href="club-stats.html"><img src="<?php echo ASSET_PATH; ?>images/soccer/team-logo1.png" width="30" height="30" alt="team-logo"></a></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-12 col-sm-12 col-xs-12">
                <p>Pabst irony tattooed, synth sriracha selvage pok pok. Wayfarers kinfolk sartorial, helvetica you probably haven't heard of them tumeric venmo deep v mixtape semiotics brunch.</p>
            </div>
        </div>
    </div>
</section>

<!--STANDING TABLE WRAP END-->