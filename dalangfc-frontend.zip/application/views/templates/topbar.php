<div class="top-bar">
    <div class="container">
        <div class="row">
            <div class="col-md-9 hidden-sm hidden-xs">
                <div class="top-contacts">
                    <ul class="socials">
                        <li><a href="#"><i class="fa fa-facebook-square" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                    </ul>
                    <ul class="contacts">
                        <li class="phone"><i class="fa fa-phone-square" aria-hidden="true"></i><?php echo COMPANY_PHONE; ?></li>
                        <li class="whatsapp"><a href="callto:team.whatsapp"><i class="fa fa-whatsapp" aria-hidden="true"></i></i><?php echo COMPANY_WA; ?></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 hidden-sm hidden-xs text-right">
                <div class="top-contacts">
                    <ul class="socials">
                        <li><a href="http://dalangfcbogordev.com" target="_blank">MASUK / DAFTAR</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>