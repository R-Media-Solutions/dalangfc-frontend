<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="" />
<meta name="keywords" content="" />

<title><?php echo TITLE; ?></title>
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Montserrat%7COpen+Sans:700,400%7CRaleway:400,800,900" />
<link rel="icon" href="<?php echo ASSET_PATH; ?>images/logo/favicon.png" type="image/x-icon">
<link rel="stylesheet" type="text/css" href="<?php echo ASSET_PATH; ?>css/library/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="<?php echo ASSET_PATH; ?>dev-assets/preloader-default.css" />
<link rel="stylesheet" type="text/css" href="<?php echo ASSET_PATH; ?>dev-assets/demo-switcher.css" />